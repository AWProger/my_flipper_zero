let math = load(__dirname + "/load_api.js");
let result = math.add(5, 10);
print(result);
